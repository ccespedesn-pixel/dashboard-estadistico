import { Router } from 'express';
import PDFDocument from 'pdfkit';
import XLSX from 'xlsx';
import { db } from '../lib/db.js';
import { actividadesConProgreso } from '../lib/progress.js';
import { currentByActivity } from '../lib/progress.js';

const router = Router();

function kpiGlobal(data) {
  const totalUnidades = data.reduce((a, d) => a + (d.total_unidades || 0), 0) || 1;
  const ponderado = data.reduce((a, d) => a + (d.pct * (d.total_unidades || 1)), 0);
  return Math.round((ponderado / totalUnidades) * 10) / 10;
}

router.get('/ejecutivo.pdf', (req, res) => {
  const data = actividadesConProgreso({});
  const prog = currentByActivity();
  const avance = kpiGlobal(data);
  const completadas = data.filter((d) => d.estado === 'Completado').length;
  const retrasos = data.filter((d) => d.estado === 'Con retraso').length;

  const causas = db.prepare(`
    SELECT cr.nombre AS causa, COUNT(*) AS frecuencia
    FROM avances av JOIN causas_retraso cr ON cr.id = av.causa_retraso_id
    GROUP BY cr.nombre ORDER BY frecuencia DESC`).all();

  const comparativo = db.prepare(`
    SELECT a.codigo, a.nombre, a.ubicacion_id, (SELECT porcentaje_avance FROM avance_actual WHERE actividad_id=a.id AND sub_actividad_id IS NULL ORDER BY id DESC LIMIT 1) AS pct
    FROM actividades a WHERE a.codigo LIKE 'COSC-%' OR a.codigo LIKE 'PAR-%'`).all();

  const doc = new PDFDocument({ size: 'A4', margin: 40 });
  res.setHeader('Content-Type', 'application/pdf');
  res.setHeader('Content-Disposition', 'attachment; filename="reporte_ejecutivo.pdf"');
  doc.pipe(res);

  doc.fontSize(18).text('REPORTE EJECUTIVO - SEGURIDAD CIUDADANA', { align: 'center' });
  doc.moveDown(0.5);
  doc.fontSize(9).fillColor('#666').text('Generado el ' + new Date().toLocaleDateString('es-ES'), { align: 'center' });
  doc.moveDown();

  doc.fontSize(12).fillColor('#000').text('1. RESUMEN GENERAL');
  doc.moveDown(0.3);
  const rows = [
    ['Avance global del proyecto', avance + '%'],
    ['Actividades completadas', completadas + ' / ' + data.length],
    ['Actividades con retraso', String(retrasos)],
  ];
  rows.forEach(([k, v]) => { doc.fontSize(10).text(`${k}:  ${v}`); });
  doc.moveDown();

  doc.fontSize(12).text('2. AVANCE POR ACTIVIDAD');
  doc.moveDown(0.3);
  doc.fontSize(8).fillColor('#555').text('Código     Actividad                                  Ubicación    Avance    Estado');
  doc.moveDown(0.1);
  doc.fillColor('#000');
  data.forEach((d) => {
    const ubi = d.ubicacion === 'COSC' ? 'COSC' : d.ubicacion === 'PAR' ? 'PAR' : 'EXT';
    doc.fontSize(8).text(`${d.codigo.padEnd(10)}  ${d.nombre.padEnd(42).slice(0, 42)}  ${ubi.padEnd(6)}    ${String(d.pct + '%').padEnd(8)}  ${d.estado}`);
  });
  doc.moveDown();

  doc.fontSize(12).text('3. ANÁLISIS DE CAUSAS');
  doc.moveDown(0.3);
  doc.fontSize(9);
  causas.forEach((c) => doc.text(`${c.causa}: ${c.frecuencia} registros`));

  doc.end();
});

router.get('/detallado.xlsx', (req, res) => {
  const rows = db.prepare(`
    SELECT av.fecha, u.codigo AS ubicacion, a.codigo AS actividad, a.nombre AS actividad_nombre,
           sa.nombre AS sub_actividad, av.cantidad_realizada, av.porcentaje_avance AS pct,
           av.estado, av.observaciones, cr.nombre AS causa, av.usuario_registro, av.fecha_registro
    FROM avances av
    JOIN actividades a ON a.id = av.actividad_id
    JOIN ubicaciones u ON u.id = a.ubicacion_id
    LEFT JOIN sub_actividades sa ON sa.id = av.sub_actividad_id
    LEFT JOIN causas_retraso cr ON cr.id = av.causa_retraso_id
    ORDER BY av.fecha DESC`).all();

  const header = ['Fecha', 'Ubicación', 'Actividad', 'Actividad Nombre', 'Sub-actividad', 'Cantidad', '% Avance', 'Estado', 'Observaciones', 'Causa', 'Usuario', 'Registro'];
  const aoa = [header, ...rows.map((r) => [r.fecha, r.ubicacion, r.actividad, r.actividad_nombre, r.sub_actividad, r.cantidad_realizada, r.pct, r.estado, r.observaciones, r.causa, r.usuario_registro, r.fecha_registro])];
  const ws = XLSX.utils.aoa_to_sheet(aoa);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'Avances');
  const buf = XLSX.write(wb, { type: 'buffer', bookType: 'xlsx' });
  res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
  res.setHeader('Content-Disposition', 'attachment; filename="registros_avances.xlsx"');
  res.send(buf);
});

export default router;